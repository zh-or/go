/*
 * Hibernate Search, full-text search for your domain model
 *
 * License: GNU Lesser General Public License (LGPL), version 2.1 or later
 * See the lgpl.txt file in the root directory or <http://www.gnu.org/licenses/lgpl-2.1.html>.
 */
package org.hibernate.search.backend;

import javax.transaction.Synchronization;

/**
 * Contract needed by Hibernate Search to batch changes per transaction.
 *
 * @author Navin Surtani  - navin@surtani.org
 */
public interface TransactionContext {
	/**
	 * @return A boolean indicating whether a transaction is in progress or not.
	 */
	boolean isTransactionInProgress();

	/**
	 * @return a transaction object.
	 */
	Object getTransactionIdentifier();

	/**
	 * Register the given synchronization.
	 *
	 * @param synchronization synchronization to register
	 */
	void registerSynchronization(Synchronization synchronization);
}
